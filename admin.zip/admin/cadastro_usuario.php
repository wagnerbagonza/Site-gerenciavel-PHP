
<?php
require_once("../seguranca/autentication_admin.php");
?>
<?php include_once("header.php"); ?>
<div id="box">
  <header id="header">
    <div id="logo"> <img src="images/logo.png" width="275"> </div>
    <!--logo-->
  </header>
  <!--header-->
  <article id="content">
    <nav id="menu">
      <?php include_once("menu_admin.php"); ?>
    </nav>
    <!--menu-->
    <section id="conteudo"> <span class="caminho">Home &raquo; Cadastrar Usuário</span>
    <h2>Cadastrar</h2>
    <?php if(isset($_POST['cadastro']) && $_POST['cadastro'] == 'ok'){
	//VARIÁVEIS PARA RECUPERAR OS VALORES NO BANCO
	$usuario = strip_tags(trim($_POST['usuario']));
	$senha   = strip_tags(trim($_POST['senha']));
	$nivel   = strip_tags(trim($_POST['nivel']));
	$nome    = strip_tags(trim($_POST['nome']));
	$email   = strip_tags(trim($_POST['email']));
	
	
$verificar_usuario = mysql_query("SELECT usuario FROM info_usuarios WHERE usuario = '$usuario'")
                     or die(mysql_error());
if(@mysql_num_rows($verificar_usuario) >= '1'){
	echo "<div class='erro_cad'>O Usuário não pode ser Cadastrado. Já existe no Banco de Dados.</div>";
}else{

	
	$cadastra_usuario = mysql_query("INSERT INTO info_usuarios (usuario, senha, nivel, nome, email)
								    VALUES ('$usuario', '$senha', '$nivel', '$nome', '$email')")
	                    or die(mysql_error());
						
	if($cadastra_usuario >= '1'){
		echo "<div class='ok'>Usuário cadastrado com sucesso!</div>";
	}else{
		echo "<div class='erro_cad'>Erro ao cadastrar Usuário!</div>";
	}
	
  }

}
?>

      <h2>Usuário</h2>
      <form name="cadastro" action="" method="post" enctype="multipart/form-data">
        <label> <span>Usuário</span>
          <input type="text" name="usuario" />
        </label>
        <label> <span>Senha</span>
          <input type="password" name="senha" />
        </label>
        <label> <span>Nivel</span>
          <select name="nivel" id="nivel">
            <option value="editor">Editor</option>
            <option value="admin">Admin</option>
          </select>
        </label>
        <label> <span>Nome</span>
          <input type="text" name="nome" />
        </label>
        <label> <span>Email</span>
          <input type="text" name="email" />
        </label>
        <input type="hidden" name="cadastro" value="ok" />
        <input type="submit" name="Cadastrar" value="Cadastrar" class="btn-cadastrar" />
      </form>
    </section>
    <!--conteudo-->
  </article>
  <!--content-->
  <div id="clear"></div>
  <!--clear-->
</div>
<!--box-->
<?php include_once("footer.php");?>