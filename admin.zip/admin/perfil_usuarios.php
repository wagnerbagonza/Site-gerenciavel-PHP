<?php
require_once("../seguranca/autentication_painel.php");
?>
<?php include_once("header.php"); ?>
<div id="box">
  <header id="header">
    <div id="logo"> <img src="images/logo.png" width="275"> </div>
    <!--logo-->
  </header>
  <!--header-->
  <article id="content">
  <nav id="menu">
    <?php include_once("menu_admin.php"); ?>
  </nav>
  <!--menu-->
  <section id="conteudo">
  <span class="caminho">Home &raquo; Editar</span>
  <h2>Editar Perfíl</h2>
  <?php if(isset($_POST['editar']) && $_POST['editar'] == 'ok'){
	
   $usuario = $_SESSION['MM_Username'];
	 $senha   = strip_tags(trim($_POST['senha']));
	 $nome    = strip_tags(trim($_POST['nome']));
	 $email   = strip_tags(trim($_POST['email']));
	 
	 $atualizar_perfil = mysql_query("UPDATE info_usuarios SET senha = '$senha', nome = '$nome', email = '$email' WHERE usuario = '$usuario'")
	                     or die(mysql_error());
						 
	 if($atualizar_perfil >= '1'){
	   echo "<div class='ok'>Seus dados foram atualizados com sucesso!</div>";
    }else{
	   echo "<div class='erro_cad'>Erro ao atualizar seus dados!</div>";
	}
	
}
?>
  <?php
	 $usuario = $_SESSION['MM_Username'];
	 $perfil = mysql_query("SELECT id_usuario, senha, nome, email FROM info_usuarios WHERE usuario = '$usuario'")
	                  or die(mysql_error());
	 if(@mysql_num_rows($perfil) <= '0') echo 'Erro ao lesecionar o usuario';
	 else{
		 
		 while($rs_perfil=mysql_fetch_array($perfil)){
			 
			 $id_usuario = $rs_perfil[0];
			 $senha = $rs_perfil[1];
			 $nome = $rs_perfil[2];
			 $email = $rs_perfil[3];

	         ?>
  <div class="usuario_editar"> <?php echo $nome;?><br />
    <?php echo $email;?> </div>
  <form name="editar_usuario" action="" enctype="multipart/form-data" method="post">
    <label> <span>Altera a Senha</span>
      <input type="password" name="senha" value="<?php echo $senha; ?>" />
    </label>
    <label> <span>Altera Nome</span>
      <input type="text" name="nome" value="<?php echo $nome;?>" />
    </label>
    <label> <span>Altera E-mail</span>
      <input type="text" name="email" value="<?php echo $email; ?>" />
    </label>
    <input type="hidden" name="editar" value="ok" />
    <input type="submit" name="Editar_usuario" value="Editar Usuário" class="btn-cadastrar" />
  </form>
  <?php
	   }
	 }
     ?>
</div>
<!--usuarios-->
</section>
<!--conteudo-->
</article>
<!--content-->
<div id="clear"></div>
<!--clear-->
</div>
<!--box-->
<?php include_once("footer.php");?>