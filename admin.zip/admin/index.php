
<?php
require_once("../seguranca/autentication_index.php");
?>
<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html;charset=iso-8859-1" />
<?php header("Content-Type: text/html; charset=ISO-8859-1",true);?>
<title>InfoNews - Admin. do Portal</title>
<link href="css/css.css" rel="stylesheet" type="text/css">
</head>

<body>

	<section id="login">
    	<img src="images/logo.png" alt="logo" width="250"/>
    	<div class="alerta">
        <p>Para ter acesso ao Painel, voc&ecirc; precisa:</p>
        <p class="txt-login">&raquo; Logar corretamente.<br />
        &raquo; Ter n&iacute;vel de acesso.</p>
        </div><!--Alerta-->
    	<form action="<?php echo $loginFormAction; ?>" method="POST" name="login_erro">
        	 <fieldset>
             	<legend>Entre com seu Login</legend>
                
                  <label>
                   <span>Usu&aacute;rio</span><br>
                   <input type="text" name="login" required /><br>
                  </label>
                  
                  <label>
                   <span>Senha</span><br>
                   <input type="password" name="senha" required /><br>
                  </label>
                  
                  <input type="submit" name="logar" value="Entrar" class="btn-logar" />
                
                </fieldset>
        </form>
    </section><!--login-->

</body>
</html>