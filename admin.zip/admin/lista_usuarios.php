	
<?php
require_once("../seguranca/autentication_admin.php");
?>
<?php include_once("header.php"); ?>
<div id="box">
  <header id="header">
    <div id="logo"> <img src="images/logo.png" width="275"> </div>
    <!--logo-->
  </header>
  <!--header-->
  <article id="content">
    <nav id="menu">
      <?php include_once("menu_admin.php"); ?>
    </nav>
    <!--menu-->
    <section id="conteudo"> <span class="caminho">Home &raquo; Usuários Listar - Editar - Excluir</span>
    <h2>Cadastrar</h2>
    
    <?php if(isset($_POST['excluir']) && $_POST['excluir'] == 'ok'){
	
	
	$id_usuario = $_POST['usuario_id'];
	
	
$verifica_usuario = mysql_query("SELECT usuario FROM info_usuarios WHERE id_usuario = '$id_usuario'")
	                  or die(mysql_error());
	 if(@mysql_num_rows($verifica_usuario) <= '0') echo 'Erro ao selecionar o usuario';
	 else{
		 
		while($rs_usuario=mysql_fetch_array($verifica_usuario)){
			 
			 $usuario = $rs_usuario[0];
		}
	 }
	
	if($usuario == 'admin'){
		echo "<div class='erro_cad'>O Usuário Admin não pode ser excluido</div>";
	}else{
	
	$deletar_usuario = mysql_query("DELETE FROM info_usuarios WHERE id_usuario = '$id_usuario'")
	                   or die(mysql_error());
					   
	if($deletar_usuario >= '1'){
		echo "<div class='ok'>Usuário foi excluido com succeso!</div>";
	}else{
		echo "<div class='erro_cad'>Erro ao excluir o usuário!</div>";
		}
  }
}
?>

<div id="usuarios">
<ul>
     <?php
	 $boas_vindas = mysql_query("SELECT id_usuario, nome, email FROM info_usuarios")
	                  or die(mysql_error());
	 if(@mysql_num_rows($boas_vindas) <= '0') echo 'Erro ao selecionar o usuario';
	 else{
		 
		 while($rs_boas_vindas=mysql_fetch_array($boas_vindas)){
			 
			 $id_usuario = $rs_boas_vindas[0];
			 $nome = $rs_boas_vindas[1];
			 $email = $rs_boas_vindas[2];
	  ?>
<li>
    <span>
<form name="excluir_usuario" action="" enctype="multipart/form-data" method="post" class="form">
  <input type="hidden" name="usuario_id" value="<?php echo $id_usuario;?>" />
  <input type="hidden" name="excluir" value="ok" />
  <input type="submit" name="Excluir" value="Excluir Usuário" class="lista_btn_excluir" />
</form>    
    
<form name="editar_usuario" action="usuario_editar.php" enctype="multipart/form-data" method="post" class="form">
  <input type="hidden" name="usuario_id" value="<?php echo $id_usuario;?>" />
  <input type="submit" name="Editar" value="Editar Usuário" class="lista_btn_editar" />
</form>


</span>
<?php echo $nome;?><br />
<?php echo $email;?>
</li>
       
    <?php
	   }
	 }
?>   
</ul>
</div><!--usuarios-->
    <!--conteudo-->
  </article>
  <!--content-->
  <div id="clear"></div>
  <!--clear-->
</div>
<!--box-->
<?php include_once("footer.php");?>