
<?php include_once("header.php"); ?>
<div id="box">
	<header id="header">
    	<div id="logo">
        	<img src="images/logo.png" width="275">
        </div><!--logo-->
    </header><!--header-->
    
    <article id="content">
    
		<nav id="menu">
           <?php require_once("menu_admin.php"); ?>
        </nav><!--menu-->
        
        <section id="conteudo">
		<span class="caminho">Home &raquo; Lista de Post</span>
		
        <?php require_once("scripts/action_excluir_post.php"); ?>
        
		<table width="100%" border="0" cellpadding="0" cellspacing="1" class="tabela">
		  <tr align="center">
		    <td bgcolor="E0E0E0">Categoria</td>
		    <td bgcolor="E0E0E0">Título do Post</td>
		    <td bgcolor="E0E0E0">Editar POST</td>
		    <td bgcolor="E0E0E0">Excluir</td>
	      </tr>
          <?php require_once("scripts/action_lista_post.php"); ?>
		  </table>
          
				<div class="paginacao_adm">
					<?php require_once("scripts/action_paginacao_admin.php"); ?>
				</div><!--PAGINACAO-->
			</section> <!--conteudo-->	
		</article><!--content-->
	<div id="clear"></div><!--clear-->
</div><!--box-->

<?php include_once("footer.php");?>