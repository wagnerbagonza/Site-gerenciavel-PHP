<?php
require_once("../seguranca/autentication_painel.php");
?>
<?php include_once("header.php"); ?>
<div id="box">
  <header id="header">
    <div id="logo"> <img src="images/logo.png" width="275"> </div>
    <!--logo-->
  </header>
  <!--header-->
  <article id="content">
    <nav id="menu">
      <?php include_once("menu_admin.php"); ?>
    </nav>
    <!--menu-->
    <section id="conteudo"> <span class="caminho">Home &raquo; Edíção de Páginas</span>
      <h2>Editar Página</h2>
      <?php 
			
		$pagina_editar = $_POST['pagina'];
		@$conteudo_editar = $_POST['conteudo'];

if(isset($_POST['cadastrar']) && $_POST['cadastrar'] == 'envia_form'){
	$cadatrar_pagina = mysql_query("INSERT INTO info_page (pagina, conteudo) VALUES ('$pagina_editar', '$conteudo_editar')")
	                   or die(mysql_error());
}

if(isset($_POST['editar_post']) && $_POST['editar_post'] == 'envia_form'){
	$atualiza_pagina = mysql_query("UPDATE info_page SET conteudo = '$conteudo_editar' WHERE pagina = '$pagina_editar'")
	                   or die (mysql_error());
	
}
			
		$pagina_de_edicao = $_POST['pagina'];
		$seleciona_pagina = mysql_query("SELECT id_page, pagina, conteudo FROM info_page WHERE pagina = '$pagina_de_edicao'")
							or die (mysql_error());
		if(@mysql_num_rows($seleciona_pagina) <= '0'){
			
			$form_cadastro = "<form name='cadastrar_pagina' method='post' action='' enctype='multipart/form-data'>
        <textarea name='conteudo' rows='30' cols='></textarea>
        <input type='hidden' name='cadastrar' value='envia_form' />
        <input type='submit' value='Cadastrar' name='Cadastrar' class='btn-cadastrar' />
      </form>";
		?>
      <?php echo $form_cadastro; ?>
      <?php
			}else{
				while($rs_pagina = mysql_fetch_array($seleciona_pagina)){
					
					$id_page = $rs_pagina[0];
					$pagina  = $rs_pagina[1];
					$conteudo = $rs_pagina[2];
					
					$form_editar = "<form name='edita_pagina' method='post' action='' enctype='multipart/form-data'>
        <input type='hidden' name='pagina' value='$pagina_de_edicao' />
        <textarea name='conteudo' rows='30' cols=''>$conteudo</textarea>
        <input type='hidden' name='editar_post' value='envia_form' />
        <input type='submit' value='Editar' name='Editar' class='btn-cadastrar' />
      </form>";
		?>
      <?php echo $form_editar; ?>
      <?php 
				}
			}
		?>
    </section>
    <!--conteudo-->
  </article>
  <!--content-->
  <div id="clear"></div>
  <!--clear-->
</div>
<!--box-->
<?php include_once("footer.php");?>