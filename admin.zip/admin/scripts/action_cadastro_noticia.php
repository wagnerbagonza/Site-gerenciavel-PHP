 <?php 
				if(isset($_POST['cadastrar_post']) && $_POST['cadastrar_post'] == 'cad'){
						
						@$id_a_editar = $_POST['id_do_post'];
						$img       = $_FILES['thumb'];
						$titulo    = $_POST['titulo'];
						$texto     = $_POST['texto'];
						$categoria = $_POST['categoria'];
						$autor     = $_POST['autor'];
						$data      = $_POST['data'];
						$autor     = $_POST['autor'];
						@$valor_real  = strip_tags(trim($_POST['valor_real']));
						@$valor_pag   = strip_tags(trim($_POST['valor_pagseguro']));
						
						$pasta = "../uploads/$categoria";
						$permitido = array('image/jpg', 'image/jpeg', 'image/pjpeg');
						
						
						require_once("scripts/function_upload.php");
							$nome = $img['name'];
		 					$tmp = $img['tmp_name'];
		 					$type = $img['type'];
							
							$entrada = trim("$data");
							if(strstr($entrada, "/")){
								$formato = explode("/", $entrada);
								$formato2 = date('H:i:s');
								$formato3 = $formato[2] . "-" . $formato[1] . "-" . $formato[0] . " " . $formato2;
								}
						if(!empty($nome) && in_array($type, $permitido)){
							$name = md5(uniqid(rand(), true)).".jpg";
							Redimensionar($tmp, $name, 500, $pasta);
								
						$cadastrar_noticias = @mysql_query("INSERT INTO info_posts (thumb, titulo, texto, categoria, data, autor, visitas) 
															VALUES ('$name','$titulo','$texto','$categoria','$formato3','$autor','1')")
												or die(mysql_error());
							if($cadastrar_noticias >= '1'){
								echo "<div class='ok'>Seu Post foi cadastrado com Sucesso!</div>";
							}else{
									echo "<div class='erro_cad'>Erro ao cadastrar o Post!</div>";
							}
						}
					}
		?>