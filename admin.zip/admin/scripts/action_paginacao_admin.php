<?php

//CRUD PARA TRAZER OS RESULTADOS
//MESMA PROPRIEDADE WHERE PARA PESQUISA
$sql_res = mysql_query("SELECT * FROM info_posts");
$total = mysql_num_rows($sql_res);

$paginas = ceil($total/$maximo);
$links = '4'; //QUANTIDADE DE LINKS NO PAGINATOR

echo "<a href=\"lista_posts.php?pag=1\"> << </a>";

for ($i = $pag-$links; $i <= $pag-1; $i++){
if ($i <= 0){
}else{
echo"<a href=\"lista_posts.php?pag=$i\">$i</a>";
}
}echo "$pag";

for($i = $pag +1; $i <= $pag+$links; $i++){
if($i > $paginas){
}else{
echo "<a href=\"lista_posts.php?pag=$i\">$i</a>";
}
}
echo "<a href=\"lista_posts.php?pag=$paginas\"> >> </a>";
?>