<?php
//CÓDIGO PARA AUTENTICAR QUANDO O USUARIO É ADMIN OU EDITOR. 
$usuario = $_SESSION['MM_Username'];
		$boas_vindas = mysql_query("SELECT nivel FROM info_usuarios WHERE usuario = '$usuario'")
			or die(mysql_error());
		if(@mysql_num_rows($boas_vindas) <= '0') echo 'Erro ao selecionar o usuário';
		else{
			while($rs_boas_vindas=mysql_fetch_array($boas_vindas)){
				$nivel = $rs_boas_vindas[0];
			
			}
		}
?>

<?php 
//CONDIÇÃO PARA ENVIAR O USUARIO (ADMIN OU EDITOR PARA SEU PAINEL DE ACORNO COM O NIVEL)
if($nivel == 'admin'){
?>    
   
<?php require_once("menu_admin.php");?>          
   
<?php
}else{
?>	
<?php require_once("menu_editor.php");?> 
<?php
		}
?>
