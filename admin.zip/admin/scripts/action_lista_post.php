<?php
if(isset($_GET['pag'])){
$pag = $_GET['pag'];
}else{
 $pag = '1';
}

$maximo = '10'; //RESULTADOS POR PÁGINA
$inicio = ($pag * $maximo) - $maximo;
		  
          $noticias =  mysql_query("SELECT 
						 	 id_post,
							 thumb, 
							 titulo, texto, 
							 categoria, 
							 `data`, 
							 autor, 
							 valor_real, 
							 valor_pagseguro,
							 visitas
							 FROM info_posts 
							 ORDER BY data DESC
							 LIMIT $inicio, $maximo")
				 or die(mysql_error());
	if(@mysql_num_rows($noticias) <='0'){
		echo "<h2>Desculpe. Estamos alimentando o Site!</h2>";
		}else{

			while($rs_noticias=mysql_fetch_array($noticias)){
				
				$id_do_post = $rs_noticias[0];
				$imagem = $rs_noticias[1];
				$titulo = $rs_noticias[2];
				$texto = $rs_noticias[3];
				$categoria = $rs_noticias[4];
				$data = $rs_noticias[5];
				$autor = $rs_noticias[6];
				$valor_real = $rs_noticias[7];
				$valor_pagseguro = $rs_noticias[8];
				$visitas = $rs_noticias[9];
?>      
<?php 
		
	
  		echo "<tr>
		    	<td bgcolor='C8C8C8' align='center'>$categoria</td>
		    	<td bgcolor='C8C8C8'>$titulo</td>
		    	<td bgcolor='C8C8C8'>
				<form name='editar_post' action='post_editar.php' actype='multipart/form-data' class='lista_posts' method='post'>
				<input type='hidden' name='id_do_post' value=$id_do_post />
				<input type='submit' name='editar' value='Editar' class='lista_btn' />
				</form>
				</td>
				<td bgcolor='C8C8C8'>
				<form name='excluir_post' action='' actype='multipart/form-data' class='lista_posts' method='post'>
				<input type='hidden' name='id_do_post' value=$id_do_post />
				<input type='hidden' name='excluir_post' value='excluir' />
				<input type='submit' name='excluir' value='Excluir' class='lista_btn_e' />
				</form>
				</td>
	        </tr>";
?>
 <?php 
 	}
  }
 ?>