<?php 
if(isset($_POST['excluir_post']) && $_POST['excluir_post'] == 'excluir'){
	
	$posts_meta = $_POST['id_do_post'];
	$pega_imagem = mysql_query("SELECT thumb, categoria FROM info_posts WHERE id_post = '$posts_meta'")
		or die (mysql_error());
		if(@mysql_num_rows($pega_imagem) <= '0'){
			echo "<div class='erro'>Erro ao selecionar o Post!</div>";
			}else{
				while($rs_pega_imagem = mysql_fetch_array($pega_imagem)){
					$thumb_meta = $rs_pega_imagem[0];
					$categoria_meta = $rs_pega_imagem[1];
					
					chdir("../uploads/$categoria_meta");
					$deleta_imagem = unlink("$thumb_meta");
							
					$deleta_post = mysql_query("DELETE FROM info_posts WHERE id_post = '$posts_meta'")
								   or die (mysql_error());
					if($deleta_post >= '1'){
						echo "<div class='ok'>Post removido com sucesso!</div>";
						}else{
							echo "<div class='erro_cad'>Erro ao tentar remover o Post!</div>";
							}
					}
			}
	}		
?>