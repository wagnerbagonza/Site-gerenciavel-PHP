       <?php 
		$visitas_total = mysql_query("SELECT Sum(visitas) AS visitas FROM info_posts")
			or die(mysql_error());
		if(@mysql_num_rows($visitas_total) <= '0') echo '';
		$views = 0;
		$visitas = mysql_result($visitas_total, $views, 'Visitas');
		
		$visitas_media = mysql_query("SELECT id_post FROM info_posts")
			or die(mysql_error());
		$linhas = mysql_num_rows($visitas_media);
		$media = @ceil($visitas/$linhas);
		
		$produtos = mysql_query("SELECT id_post FROM info_posts WHERE categoria = 'produtos'")
			or die(mysql_error());
		$rs_produtos = mysql_num_rows($produtos);
		
		$novidades = mysql_query("SELECT id_post FROM info_posts WHERE categoria = 'novidades'")
			or die(mysql_error());
		$rs_novidades = mysql_num_rows($novidades);
		
		$tecnologia = mysql_query("SELECT id_post FROM info_posts WHERE categoria = 'tecnologia'")
			or die(mysql_error());
		$rs_tecnologia = mysql_num_rows($tecnologia);
		
		$diversos = mysql_query("SELECT id_post FROM info_posts WHERE categoria = 'diversos'")
			or die(mysql_error());
		$rs_diversos = mysql_num_rows($diversos);
		
		
		
		
		$resultado_visitas = "<h2>Visitas em seus Posts</h2>
							  <strong>Visitas = $visitas</strong>";
							  
		$resultado_media = "<h2>Média de visitas no Site</h2>
							<strong>Visitas = $media</strong>";
		
		$total_posts = "<h2>Total de Posts no Portal</h2>
						<strong>Posts Encontrados = $linhas</strong><br/>
						<strong>$rs_novidades em novidades | $rs_tecnologia em tecnologia | $rs_produtos em produtos | $rs_diversos em diversos</strong>";
		
		
	
		?>