<?php
require_once("../../seguranca/autentication_painel.php");
require_once("select_categoria.php");
?>

<?php include_once("../header.php"); ?>

<div id="box">
	<header id="header">
    	<div id="logo">
        	<img src="../images/logo.png" width="275">
        </div><!--logo-->
    </header><!--header-->
    
    <article id="content">
    	<nav id="menu">
           <?php include_once("../menu_admin.php"); ?>
        </nav><!--menu-->
        
        <section id="conteudo">
			<span class="caminho">Home &raquo; Editar Post</span>
            
            <h2>Editar Post</h2>
            <?php 
 	if(isset($_POST['editar_post']) && $_POST['editar_post'] == 'cad'){
		
						$id_a_editar = $_POST['id_do_post'];
   					$img         = $_FILES['thumb'];
						$titulo      = strip_tags(trim($_POST['titulo']));
						$texto       = $_POST['texto'];
						$categoria   = strip_tags(trim($_POST['categoria']));
						$data        = strip_tags(trim($_POST['data']));
						$autor       = $_POST['autor'];
						
						$pasta = "../uploads/$categoria";
						$permitido = array('image/jpg', 'image/jpeg', 'image/pjpeg');
						
						
						require_once("function_upload.php");
							$nome = $img['name'];
		 					$tmp = $img['tmp_name'];
		 					$type = $img['type'];
							
							$entrada = trim("$data");
							if(strstr($entrada, "/")){
								$formato = explode("/", $entrada);
								$formato2 = date('H:i:s');
								$formato3 = $formato[2] . "-" . $formato[1] . "-" . $formato[0] . " " . $formato2;
						}
					}
		
	if(empty($_FILES['thumb']['name'])){

   $editar_posts = @mysql_query("UPDATE info_posts SET titulo = '$titulo', texto = '$texto', categoria = '$categoria', 
							   data = '$formato3', autor = '$autor' WHERE id_post = '$id_a_editar'")
                   or die(mysql_error());
				   
	if($editar_posts >= '0'){
					echo "<div class='ok'>Seu Post foi atualizado com sucesso!</div>";
				}else{
					echo "<div class='erro_cad'>Erro ao atualizar o Post</div>";
		   }

}else{
	
	$pega_imagem = mysql_query("SELECT thumb, categoria FROM info_posts WHERE id_post = '$id_a_editar'")
	               or die (mysql_error());
				   
	if(@mysql_num_rows($pega_imagem) <= '0'){
		echo "<div class=\"no\">Erro ao selecionar o post</div>";
	}else{
		while($rs_pega_imagem=mysql_fetch_array($pega_imagem)){
			
			$thumb_meta = $rs_pega_imagem[0];
			$categoria_meta = $rs_pega_imagem[1];
			
			chdir("../uploads/$categoria_meta");
			$del = unlink("$thumb_meta");
			
		}
	}
		 
		 if(!empty($nome) && in_array($type, $permitido)){
				$name = md5(uniqid(rand(), true)).".jpg";
				Redimensionar($tmp, $name, 500, $pasta);	
	            $editar_posts = mysql_query("UPDATE info_posts SET thumb = '$name', titulo = '$titulo', texto = '$texto', categoria = '$categoria', 
							   data = '$formato3', autor = '$autor' WHERE id_post = '$id_a_editar'")
                   or die(mysql_error());
				   
	            if($editar_posts >= '1'){
					echo "<div class='ok'>Seu Post foi atualizado com sucesso!</div>";
				}else{
					echo "<div class='erro_cad'>Erro ao atualizar o Post</div>";
		   }
		 }
	}

?>
<?php 
		   		$editar_post_id = $_POST['id_do_post'];
				
				$noticias =  mysql_query("SELECT 
						 	 id_post,
							 thumb, 
							 titulo, texto, 
							 categoria, 
							 `data`, 
							 autor, 
							 valor_real, 
							 valor_pagseguro,
							 visitas
							 FROM info_posts 
							 WHERE id_post = '$editar_post_id'")
				 or die(mysql_error());
	if(@mysql_num_rows($noticias) <='0'){
		echo "Desculpe. Estamos alimentando o Site!";
		}else{

			while($rs_noticias=mysql_fetch_array($noticias)){
				
				$id_do_post = $rs_noticias[0];
				$imagem = $rs_noticias[1];
				$titulo = $rs_noticias[2];
				$texto = $rs_noticias[3];
				$categoria = $rs_noticias[4];
				$data = $rs_noticias[5];
				$autor = $rs_noticias[6];
				$valor_real = $rs_noticias[7];
				$valor_pagseguro = $rs_noticias[8];
				$visitas = $rs_noticias[9];
?>      
            
            <form name="editar_post" method="post" enctype="multipart/form-data">
            	<fieldset>
                     	<label>
                        <span>Imagem de Exibição <strong>(Necessaria somente se quiser altera-la)</strong>.</span>
                        	<input type="file" name="thumb" class="select-img"/>
                        </label>
                        
                        <label>
                        <span>Título</span>
                        	<input type="text" name="titulo" value="<?php echo $titulo;?>" required/>
                        </label>
                        
                        <label>
                        <span>Texto</span>
                        	<textarea name="texto" rows="5" required><?php echo $texto;?></textarea>
                        </label>
                        
                        <label>
                        <span>Categoria</span>
                        
                        <select name="categoria" id="categoria" required>
     			     		<option value="<?php echo $categoria;?>"><?php echo $categoria;?></option>
                   		</select>
                        </label>
                        
                        <label>
                        <span>Data</span>
                        	<input type="text" name="data" value="<?php echo date('d/m/Y', strtotime($data));?>" />
                        </label>
                              
                        <label>
                        <span>Autor</span>
                        	<input type="text" name="autor" value="<?php echo $autor; ?>" required/>
                        </label>
                        <input type='hidden' name='id_do_post' value="<?php echo $id_do_post; ?>" />
                        <input type="hidden" name="editar_post" value="cad"/>
                        <input type="submit" value="Editar" name="editar" class="btn-cadastrar" />
                                        
                </fieldset>
            </form>
            
       <?php 
 	}
  }
 ?>
        </section><!--conteudo-->	
    </article><!--content-->
    <div id="clear"></div><!--clear-->
</div><!--box-->

<?php include_once("../footer.php");?>