 <?php 
				if(isset($_POST['cadastrar_produto']) && $_POST['cadastrar_produto'] == 'cad'){
						$img       = $_FILES['thumb'];
						$titulo    = $_POST['titulo'];
						$texto     = $_POST['texto'];
						$categoria = $_POST['categoria'];
						$autor     = $_POST['autor'];
						$valor_real     = $_POST['valor_real'];
						$valor_pagseguro     = $_POST['valor_pagseguro'];
						
						$pasta = "../uploads/$categoria";
						$permitido = array('image/jpg','image/jpeg','image/pjpeg');
						require_once("scripts/function_upload.php");
							$nome = $img['name'];
							$tmp = $img['tmp_name'];
							$type = $img['type'];
							
						if(!empty($nome) && in_array($type, $permitido)){
							$name = md5(uniqid(rand(), true)).".jpg";
								Redimensionar($tmp, $name, 500, $pasta);
								
						$cadastrar_noticias = mysql_query("INSERT INTO info_posts (thumb, titulo, texto, categoria, autor, valor_real, valor_pagseguro, visitas) 
															VALUES ('$name','$titulo','$texto','$categoria','$autor','$valor_real','$valor_pagseguro','1')")
												or die(mysql_error());
							if($cadastrar_noticias >= '1'){
								echo "<div class='ok'>Seu Produto foi cadastrado com Sucesso!</div>";
							}else{
									echo "<div class='erro_cad'>Erro ao cadastrar o Produto!</div>";
							}
						}
					}
			?>