<?php
	$categorias = array('Novidades','Produtos','Diversos','Tecnologia');
	$categ_option = "<select name='categoria'>\n
						<option value='-1'>Selecione Categoria</option>";
		foreach($categorias as $valor){
			$categ_option .= "<option value='$valor'>$valor</option>";
		}
	$categ_option .= "</select>";
?>
