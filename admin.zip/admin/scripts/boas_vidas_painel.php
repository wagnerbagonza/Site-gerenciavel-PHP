<?php
$usuario = $_SESSION['MM_Username'];
		$boas_vindas = mysql_query("SELECT nome, email FROM info_usuarios WHERE usuario = '$usuario'")
			or die(mysql_error());
		if(@mysql_num_rows($boas_vindas) <= '0') echo 'Erro ao selecionar o usuário';
		else{
			while($rs_boas_vindas=mysql_fetch_array($boas_vindas)){
				$nome = $rs_boas_vindas[0];
				$email = $rs_boas_vindas[1];
				
			$dia = date('d');
			$mes = date('m');
			$ano = date('Y');
			$hora = date('H:i');
			$msg_boas_vidas = "<h2>Boas Vindas</h2>
							  <strong>Bem vindo sr. $nome, hoje dia $dia do $mes de $ano.<br/> Horário de Brasília: $hora </strong>";
			}
		}
?>