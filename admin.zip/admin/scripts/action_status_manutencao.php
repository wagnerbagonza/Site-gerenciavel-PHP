<?php 
if(isset($_POST['alterar']) && $_POST['alterar'] == 'ok'){
		
		$status = $_POST['status'];
		
		$alterar = mysql_query("UPDATE info_manutencao SET status = '$status'")
		           or die(mysql_error());
				   
		if($alterar >= '1'){
			echo "<div class=\"ok\">Status alterado com sucesso para <strong>$status!</strong></div>";
		}else{
			echo "<div class=\"no\">Erro ao alterar o status!</div>";
		}
}
		
?>