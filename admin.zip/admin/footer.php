<footer id="rodape">
<div id="txt-rodape">
&copy; 2012 - <?php echo date('Y');?> Tecnologia em Sistemas para Internet<br/>
Projeto Integrador<br/>
Todos os Direitos Reservados.
</div><!--txt-rodape-->

<div id="img-rodape">
<a href="http://localhost/pi-projeto/"><img src="../images/logo-infonews.png" width="175"/></a>
</div><!--img-rodape-->
</footer><!--rodape-->

</body>
</html>