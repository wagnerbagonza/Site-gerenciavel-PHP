<?php
require_once("../seguranca/autentication_painel.php");
?>
<?php include_once("header.php"); ?>
<div id="box">
  <header id="header">
    <div id="logo"> <img src="images/logo.png" width="275"> </div>
    <!--logo-->
  </header>
  <!--header-->
  <article id="content">
    <nav id="menu">
      <?php include_once("menu_admin.php"); ?>
    </nav>
    <!--menu-->
    <section id="conteudo"> <span class="caminho">Home &raquo; Manutenção</span>
      <h2>Modo de Manutenção</h2>
      <p><strong>Se modo estivar Ativo:</strong> o site só poderá ser visualizado estando logado no painel</p>
      <p>Mantenha Desativo para seus usuários poderem navegar</p>
     <?php include_once("scripts/action_status_manutencao.php"); ?>
      <form name="manu" action="" method="post" enctype="multipart/form-data">
        <select name="status" id="status">
          <option value="inativo">Desativar</option>
          <option value="ativo">Ativar</option>
        </select>
        <input type="hidden" name="alterar" value="ok" />
        <input type="submit" name="Alterar" value="Alterar Status" class="btn-pagina" />
      </form>
    </section>
    <!--conteudo-->
  </article>
  <!--content-->
  <div id="clear"></div>
  <!--clear-->
</div>
<!--box-->
<?php include_once("footer.php");?>