

<?php
require_once("../seguranca/autentication_error_login.php");
?>

<!DOCTYPE html>
<head>
<meta charset="utf-8"> 
<title>InfoNews - Admin. do Portal</title>
<link href="css/css.css" rel="stylesheet" type="text/css">
</head>

<body>

	<section id="login">
    	<img src="images/logo.png" alt="logo" width="250"/>
    	<div class="alerta">
        <p>Para ter acesso ao Painel, você precisa:</p>
        <p class="txt-login">&raquo; Logar corretamente.<br />
        &raquo; Ter nível de acesso.</p>
        </div><!--Alerta-->
    	<form action="<?php echo $loginFormAction; ?>" method="POST" name="login_erro">
        	 <fieldset>
             	<legend class="error_login">Login ou Senha Inválidos!</legend>
                
                  <label>
                   <span>Usuário</span><br>
                   <input type="text" name="login" required /><br>
                  </label>
                  
                  <label>
                   <span>Senha</span><br>
                   <input type="password" name="senha" required /><br>
                  </label>
                  
                  <input type="submit" name="logar" value="Entrar" class="btn-logar" />
                
                </fieldset>
        </form>
    </section><!--login-->

</body>
</html>