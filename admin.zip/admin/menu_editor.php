<h1>Editor do Portal</h1>
<ul>
    <li><a href="painel.php">Voltar ao Início</a></li>
</ul>
    	<h1>Administrar Conteúdo</h1>
<ul>
    <li><a href="post_cadastro.php">Cadastrar novos Posts</a></li>
    <li><a href="post_produtos.php">Cadastrar novos Produtos</a></li>
    <li><a href="lista_posts.php">Listar conteúdo</a></li>
</ul>
		<h1>Administrar Páginas</h1>
<ul>
	<li><a href="pagina_edit.php">Edição de Páginas</a></li>
</ul>
        <h1>Administrar Usuários</h1>
<ul>
	<li><a href="perfil_usuarios.php">Editar Perfíl</a></li>
</ul>
        <h1>Funções</h1>
<ul>
    <li><a href="../" target="_blank">Visualizar o Portal</a></li>
    <li><a href="deslogar.php">Sair do Painel</a></li>
</ul>