<?php
require_once("../seguranca/autentication_painel.php");
require_once("scripts/select_categoria.php");
?>
<?php header("meta http-equiv='Content-Type' content='text/html; charset=utf-8",true);?>
<?php include_once("header.php"); ?>

<div id="box">
	<header id="header">
    	<div id="logo">
        	<img src="images/logo.png" width="275">
        </div><!--logo-->
    </header><!--header-->
    
    <article id="content">
    	<nav id="menu">
           <?php include_once("menu_admin.php"); ?>
        </nav><!--menu-->
        
        <section id="conteudo">
			<span class="caminho">Home &raquo; Cadastrar Produto</span>
            
            <h2>Cadastrar Produto</h2>
            
           <?php require_once("scripts/action_cadastro_produto.php"); ?>
            
            <form name="cadastrar_produto" method="post" enctype="multipart/form-data">
            	<fieldset>
             
                        <span>Imagem do Produto</span>
                        	<input type="file" name="thumb" class="select-img" required />
                        </label>
                        
                        <label>
                        <span>Nome do Produto</span>
                        	<input type="text" name="titulo" required />
                        </label>
                        
                        <label>
                        <span>Descrição</span>
                        	<textarea name="texto" rows="5" ></textarea>
                        </label>
                        
                        <label>
                        <span>Fabricante</span>
                        	<input type="text" name="autor" required />
                        </label>
                        
                        <div id="produtos_class">
                        <label>
                        <span>Valor R$</span>
                        	<input type="text" name="valor_real" required placeholder="Ex: 10,00"/>
                        </label>
                        
                        <label>
                        <span>Valor PagSeguro</span>
                        	<input type="text" name="valor_pagseguro" required placeholder="Ex: Sem virgula 1000 "/>
                        </label>
                        <span>Categoria</span>
                        <select name="categoria" id="categoria">
                     		<option value="produtos" id="produtos">Produtos</option>   
                   		</select>
                        </label>
                        </div><!--class produtos_class-->
                        <input type="hidden" name="cadastrar_produto" value="cad"/>
                        <input type="submit" value="Cadastrar" name="cadastrar" class="btn-cadastrar" />
                                        
                </fieldset>
            </form>
        </section><!--conteudo-->	
    </article><!--content-->
    <div id="clear"></div><!--clear-->
</div><!--box-->

<?php include_once("footer.php");?>