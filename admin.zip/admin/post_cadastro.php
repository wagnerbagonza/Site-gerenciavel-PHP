<?php
require_once("../seguranca/autentication_painel.php");
require_once("scripts/select_categoria.php");
?>
<?php header("meta http-equiv='Content-Type' content='text/html; charset=utf-8",true);?>
<?php include_once("header.php"); ?>

<div id="box">
	<header id="header">
    	<div id="logo">
        	<img src="images/logo.png" width="275">
        </div><!--logo-->
    </header><!--header-->
    
    <article id="content">
    	<nav id="menu">
           <?php include_once("menu_admin.php"); ?>
        </nav><!--menu-->
        
        <section id="conteudo">
			<span class="caminho">Home &raquo; Cadastrar Post</span>
            <h2>Cadastrar Post</h2>
            
           <?php require_once("scripts/action_cadastro_noticia.php"); ?>
            
            <form name="cadastrar_post" method="post" enctype="multipart/form-data">
            	<fieldset>
                     	<label>
                        <span>Imagem de Exibição</span>
                        	<input type="file" name="thumb" class="select-img" required />
                        </label>
                        
                        <label>
                        <span>Título</span>
                        	<input type="text" name="titulo" required/>
                        </label>
                        
                        <label>
                        <span>Texto</span>
                        	<textarea name="texto" rows="5"></textarea>
                        </label>
                        
                        <label>
                        <span>Categoria</span>
                        <select name="categoria" id="categoria" required>
     			     		<option value="">Selecione a Categoria</option>
                     		<option value="novidades" id="novidades">Novidades</option>
                     		<option value="tecnologia" id="tecnologia">Tecnologia</option>    
                     		<option value="diversos" id="diversos">Diversos</option>     
                   		   </select>
                        </label>
                        
                        <label>
                        <span>Data</span>
                        	<input type="date" name="data" required placeholder="dd/mm/aaaa"/>
                        </label>
                        
                        <label>
                        <span>Autor</span>
                        	<input type="text" name="autor" required/>
                        </label>
                        <input type="hidden" name="cadastrar_post" value="cad"/>
                        <input type="submit" value="Cadastrar" name="cadastrar" class="btn-cadastrar" />
                                        
                </fieldset>
            </form>
        </section><!--conteudo-->	
    </article><!--content-->
    <div id="clear"></div><!--clear-->
</div><!--box-->

<?php include_once("footer.php");?>