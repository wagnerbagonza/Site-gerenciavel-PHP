<?php
require_once("../seguranca/autentication_painel.php");
?>

<?php include_once("header.php"); ?>
<div id="box">
	<header id="header">
    	<div id="logo">
        	<img src="images/logo.png" width="275">
        </div><!--logo-->
    </header><!--header-->
    
    <article id="content">
    	<nav id="menu">
           <?php include_once("scripts/action_menu_nivel.php"); ?>
        </nav><!--menu-->
        
        <section id="conteudo">
 			
        	<?php require_once("scripts/contagem_visitas.php"); ?>
            <?php require_once("scripts/boas_vidas_painel.php"); ?>
            
        	<?php echo $msg_boas_vidas ?>
            
            <?php echo $resultado_visitas; ?>
            <?php echo $resultado_media; ?>
            <?php echo $total_posts ?>
          
        </section><!--conteudo-->	
    </article><!--content-->
    <div id="clear"></div><!--clear-->
</div><!--box-->

<?php include_once("footer.php");?>