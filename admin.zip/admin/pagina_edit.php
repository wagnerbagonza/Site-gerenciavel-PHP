<?php
require_once("../seguranca/autentication_painel.php");
?>
<?php include_once("header.php"); ?>
<div id="box">
  <header id="header">
    <div id="logo"> <img src="images/logo.png" width="275"> </div>
    <!--logo-->
  </header>
  <!--header-->
  <article id="content">
    <nav id="menu">
      <?php include_once("menu_admin.php"); ?>
    </nav>
    <!--menu-->
    <section id="conteudo"> <span class="caminho">Home &raquo; Edíção de Páginas</span>
      <h2>Editar Página</h2>
      <form name="edit_pagina" method="post" action="pagina_cadastro.php" enctype="multipart/form-data">
        <select name="pagina" id="pagina">
          <option value="-1">Selecione a Página</option>
          <option value="sobre">Sobre</option>
          <option value="entretenimento">Entretenimento</option>
          <option value="produtos">Produtos</option>
        </select>
        <input type="submit" name="editar" value="Editar" class="btn-pagina" />
      </form>
    </section>
    <!--conteudo-->
  </article>
  <!--content-->
  <div id="clear"></div>
  <!--clear-->
</div>
<!--box-->
<?php include_once("footer.php");?>