<div id="page-conteudo">

	<div id="sidebar">
		<?php include_once("sidebars/sidebar.php");?>
    </div><!--SIDEBAR-->
    
    <div id="page">
    	<h1>Obrigado por entrar em Contato</h1>
        <h2>Breve Responderemos seu E-mail</h2>
    </div><!--PAGE-->
</div><!--PAGE-CONTEUDO-->