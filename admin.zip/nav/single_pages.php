
<div id="page-conteudo">

	<div id="sidebar">
		<?php include("sidebars/sidebar.php");?>
    </div><!--SIDEBAR-->
    
    <div id="page">
		<?php include_once("libraries/pages_posts.php");?>
    </div><!--PAGE-->
</div><!--PAGE-CONTEUDO-->
