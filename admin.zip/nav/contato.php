<div id="page-conteudo">

	<div id="sidebar">
		<?php include_once("sidebars/sidebar.php");?>
    </div><!--SIDEBAR-->
    
    <div id="page">
    	<h1>Contato</h1>
        <h2>Fale Conosco</h2>
        

        <form method="post" action="index.php?infonews=nav/validaForm" name="contato">
        
       <fieldset>
       <legend>Preencha o Formulario</legend>
        
        <label>
        <span>Nome:</span>
        <input type="text" name="nome" required />
        </label>
        <label>
        <span>E-mail:</span>
        <input type="email" required name="email" />
        </label>
        <label>
        <span>Telefone:</span>
        <input required name="telefone" pattern="\([0-9]{2}\)[\s][0-9]{4}-[0-9]{4}">
        </label>
        <label>
        <span>Assunto:</span>
        <input type="text" name="assunto" required />
        </label>
        <label>
        <span>Mensagem:</span>
        <textarea name="mensagem" rows="5" required></textarea>
        </label>
         </fieldset>
         <input type="hidden" name="envio" value="send" />
        <input type="submit" name="enviar" value="Enviar" class="btn_contato" />
        </form>
    </div><!--PAGE-->
</div><!--PAGE-CONTEUDO-->