<?php if(isset($_POST['envio']) && $_POST['envio'] == 'send'){

	$nome =     strip_tags(trim($_POST['nome']));
	$email =    strip_tags(trim($_POST['email']));
	$telefone = strip_tags(trim($_POST['telefone']));
	$assunto =  strip_tags(trim($_POST['assunto']));
	$mensagem = strip_tags(trim($_POST['mensagem']));


$date = date("d/m/Y h:i");

// ****** ATEN��O ********
// ABAIXO EST� A CONFIGURA��O DO SEU FORMUL�RIO.
// ****** ATEN��O ********

//CABE�ALHO - ONFIGURA��ES SOBRE SEUS DADOS E SEU WEBSITE
$nome_do_site="Infonews";
$email_para_onde_vai_a_mensagem = "contato@uiltonrocha.com.br";
$nome_de_quem_recebe_a_mensagem = "Infonews";
$exibir_apos_enviar='index.php?infonews=nav/enviado';

//MAIS - CONFIGURA�OES DA MENSAGEM ORIGINAL
$cabecalho_da_mensagem_original="From: $name <$email>\n";
$assunto_da_mensagem_original="Fale com InfoNews";

// FORMA COMO RECEBER� O E-MAIL (FORMUL�RIO)
$configuracao_da_mensagem_original="

ENVIADO POR:\n
Nome: $nome\n
E-mail: $email\n
Telefone: $telefone\n
Assunto: $assunto\n\n
Mensagem: $mensagem\n\n

ENVIADO EM: $date";

//CONFIGURA��ES DA MENSAGEM DE RESPOSTA
// CASO $assunto_digitado_pelo_usuario="s" ESSA VARIAVEL RECEBERA AUTOMATICAMENTE A CONFIGURACAO
// "Re: $assunto"
$assunto_da_mensagem_de_resposta = "Recebemos seu email";
$cabecalho_da_mensagem_de_resposta = "From: $nome_do_site <$email_para_onde_vai_a_mensagem>\n";
$configuracao_da_mensagem_de_resposta="

Obrigado por entrar em contato!\n
Estaremos respondendo em breve...\n
Atenciosamente,\n$nome_do_site\n\n

Enviado em: $date";

//ESSA VARIAVEL DEFINE SE � O USUARIO QUEM DIGITA O ASSUNTO OU SE DEVE ASSUMIR O ASSUNTO DEFINIDO
//'assunto' NO FORMULARIO DE ENVIO
$assunto_digitado_pelo_usuario="s";

//ENVIO DA MENSAGEM ORIGINAL
$headers = "$cabecalho_da_mensagem_original";
if ($assunto_digitado_pelo_usuario=="s")
{
$assunto = "$assunto_da_mensagem_original";
};
$seuemail = "$email_para_onde_vai_a_mensagem";
$mensagem = "$configuracao_da_mensagem_original";
mail($seuemail,$assunto,$mensagem,$headers);

//ENVIO DE MENSAGEM DE RESPOSTA AUTOMATICA
$headers = "$cabecalho_da_mensagem_de_resposta";
if ($assunto_digitado_pelo_usuario=="s")
{
$assunto = "$assunto_da_mensagem_de_resposta";
}
else
{
$assunto = "Re: $assunto";
};
$mensagem = "$configuracao_da_mensagem_de_resposta";
mail($email,$assunto,$mensagem,$headers);

echo "<script>window.location='$exibir_apos_enviar'</script>";
} else {
	echo "$retorno";
  }
?>