<div id="page-conteudo">
	
    <div id="sidebar">
		<?php include("sidebars/sidebar.php");?>
    </div><!--SIDEBAR-->
    
    <div id="page">
		<?php include_once("libraries/inclui_pagina.php");?>
    </div><!--PAGE-->
</div><!--PAGE-CONTEUDO-->