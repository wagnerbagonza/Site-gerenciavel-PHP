    	
        <div id="destaques">
        	<aside id="noticias_destaque">
        		<?php
				$recupera = 'destaque';//VARI�VEL PARA RECUPERAR O VALOR DA CATEGORIA NO BANCO 
				include("libraries/inclui_posts.php"); 
				?>
        	</aside><!--NOTICIAS DESTAQUE-->
        		<span id="pager" class="pager"></span>
        </div><!--DESTAQUES-->
        
        <div id="noticia_lista">
            <?php
				$recupera = 'lista';
				include("libraries/inclui_posts.php"); 
			?>
        </div><!--NOTICIAS LISTA-->
        
        <div id="tecnologia">
        <div id="tecnologia_lista">
        	<?php
				$recupera = 'tecnologia';//VARI�VEL PARA RECUPERAR O VALOR DA CATEGORIA NO BANCO 
				include("libraries/inclui_posts.php"); 
			?>
        </div><!--tecnologia LISTA-->
        
        <div id="tecnologia_shopping">
        <h1>Mini Shopping</h1>
        
        <div class="carrosel">
       	<?php
			$recupera = 'produtos';//VARI�VEL PARA RECUPERAR O VALOR DA CATEGORIA NO BANCO 
			include("libraries/inclui_posts.php"); 
		?>
        </div><!--CARROSEL-->
        <a href="index.php?infonews=nav/categoria&amp;cat=produtos">
        <div class="btn_tecnologia"></div><!--BTN tecnologia-->
        </a>
        </div><!--tecnologia SHOPPING-->
        
        </div><!--tecnologia-->
        
        <div id="diversos">
        <?php
			$recupera = 'diversos';//VARI�VEL PARA RECUPERAR O VALOR DA CATEGORIA NO BANCO 
			include("libraries/inclui_posts.php"); 
		?>
        </div><!--diversos-->