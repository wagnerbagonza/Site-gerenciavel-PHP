<div id="page-conteudo">
  <div id="sidebar">
    <?php include"sidebars/sidebar.php";?>
  </div>
  <!--sidebar-->
  <div id="page">
    <?php 
//VARIÁVEL PARA PAGINAÇÃO
if(isset($_GET['pag'])){
$pag = $_GET['pag'];	
}else{
 $pag = '1';
}

$maximo = '5'; //RESULTADOS POR PÁGINA
$inicio = ($pag * $maximo) - $maximo;

$infonew = $_GET['cat'];
$noticias =  mysql_query("SELECT 
						 	 id_post,
							 thumb, 
							 titulo, 
							 texto, 
							 categoria, 
							 `data`, 
							 autor, 
							 valor_real, 
							 valor_pagseguro,
							 visitas
							 FROM info_posts 
							 WHERE categoria = '$infonew'
							 ORDER BY data DESC
							 LIMIT $inicio, $maximo")
				 or die(mysql_error());
	if(@mysql_num_rows($noticias) <='0'){
		echo "Desculpe. Estamos alimentando o Site!";
		}else{
			
			$numero = '0';
			while($rs_noticias=mysql_fetch_array($noticias)){
				
				$id_post = $rs_noticias[0];
				$thumb = $rs_noticias[1];
				$titulo = $rs_noticias[2];
				$texto = $rs_noticias[3];
				$categoria = $rs_noticias[4];
				$data = $rs_noticias[5];
				$autor = $rs_noticias[6];
				$valor_real = $rs_noticias[7];
				$valor_pagseguro = $rs_noticias[8];
				$visitas = $rs_noticias[9];
				$numero++;
?>
    <div class="categoria"> <a href="index.php?infonews=nav/single_pages&amp;infonew=<?php echo $id_post; ?>">
      <h1><?php echo $titulo; ?></h1>
      <p class="info">Autor: <?php echo $autor; ?> | Categoria: <?php echo $categoria; ?> | Visitas: <?php echo $visitas; ?></p>
      <img src="uploads/<?php echo $categoria; ?>/<?php echo $thumb; ?>" alt="" width="100" class="alinleft"/>
      <p class="posts"><?php echo strip_tags(trim(str_truncate($texto, 400))); ?>...<strong>Continue Lendo.</strong></p>
      </a> </div>
    <!--CATEGORIA-->
    <?php
	}
}
?>
    <div class="paginacao">
      <?php

//MESMA SQL USADA PARA RECUPERAR OS RESULTADOS
$sql_res = mysql_query("SELECT * FROM info_posts WHERE categoria = '$infonew'");
$total = mysql_num_rows($sql_res);

$paginas = ceil($total/$maximo);
$links = '5'; //QUANTIDADE DE LINKS NA PAGINAÇÃO

echo "<a href=\"index.php?infonews=nav/categoria&amp;cat=$categoria&amp;pag=1\"> << </a>";

for ($i = $pag-$links; $i <= $pag-1; $i++){
if ($i <= 0){
}else{
echo"<a href=\"index.php?infonews=nav/categoria&amp;cat=$categoria&amp;pag=$i\">$i</a>";
}
}echo "$pag &nbsp;&nbsp;&nbsp;";

for($i = $pag +1; $i <= $pag+$links; $i++){
if($i > $paginas){
}else{
echo "<a href=\"index.php?infonews=nav/categoria&amp;cat=$categoria&amp;pag=$i\">$i</a>";
}
}
echo "<a href=\"index.php?infonews=nav/categoria&amp;cat=$categoria&amp;pag=$paginas\"> >> </a>";
?>
    </div>
    <!--PAGINACAO-->
  </div>
  <!--PAGE-->
</div>
<!--PAGE-CONTEUDO-->
<?php
if(isset($_GET['visitas'])){
//CÓDIGO PARA CONTAR AS VISITAS
$add_visitas = $visitas + 1;

$info_visitas = mysql_query("UPDATE 
							info_posts 
							SET visitas = '$add_visitas' WHERE id_post = '$infonew'")
	or die(mysql_error());
}
?>
