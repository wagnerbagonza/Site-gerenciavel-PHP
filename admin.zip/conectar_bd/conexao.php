<?php
//C�DIGO PARA FAZER A CONEX�O COM O BANCO DE DADOS MYSQL
$conexao = mysql_connect("$hostname_config", "$username_config", "$password_config")
		or die(mysql_error("Erro ao conectar com o Banco de Dados."));
$db = mysql_select_db("$database_config")
		or die(mysql_error("Erro ao selecionar a Base de Dados."));

$verificar_manu = mysql_query("SELECT status FROM info_manutencao WHERE status = 'ativo'")
                  or die(mysql_error());
if(@mysql_num_rows($verificar_manu) >= '1' && (empty($_SESSION['MM_Username']))){
	echo "<h1 style='text-align:center; font-family:Arial, Helvetica, sans-serif; color:#F90; margin-top:100px;'>Site em manuten��o, favor volte mais tarde!</h1>";
	exit;
}
$info_not = 'Site em Manuten��o, favor volte mais tarde!';
?>