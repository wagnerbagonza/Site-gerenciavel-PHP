<ul>
<?php 
//SELECIONA A CATEGORIA E SETA O LIMITE NA HOME
if($recupera == 'destaque'){
	$limite = '3';
	$quando = 'novidades';
}else if($recupera == 'lista'){
	$limite = '3,5';
	$quando = 'novidades';
}else if($recupera == 'tecnologia'){
	$limite = '3';
	$quando = 'tecnologia';
}else if($recupera == 'produtos'){
	$limite = '16';
	$quando = 'produtos';
}else if($recupera == 'diversos'){
	$limite = '1';
	$quando = 'diversos';
}
//RECUPERA AS NOTICIAS E PRODUTOS DE VENDA ATRAVÉS DA CONDIÇÃO IF E ELSE.
$noticias =  mysql_query("SELECT 
						 	 id_post,
							 thumb, 
							 titulo, texto, 
							 categoria, 
							 `data`, 
							 autor, 
							 valor_real, 
							 valor_pagseguro 
							 FROM info_posts 
							 WHERE categoria = '$quando'
							 ORDER BY data DESC
							 LIMIT $limite ")
				 or die(mysql_error());
	if(@mysql_num_rows($noticias) <='0'){
		echo "$info_not";
		}else{
			
			$numero = '0';
			while($rs_noticias=mysql_fetch_array($noticias)){
				
				$id_do_post = $rs_noticias[0];
				$imagem = $rs_noticias[1];
				$titulo = $rs_noticias[2];
				$texto = $rs_noticias[3];
				$categoria = $rs_noticias[4];
				$data = $rs_noticias[5];
				$autor = $rs_noticias[6];
				$valor_real = $rs_noticias[7];
				$valor_pagseguro = $rs_noticias[8];
				$numero++;
?>
<?php 
if($recupera == 'destaque'){
?>
<!--LISTA AS NOTICIAS DENTRO DO LOOPING E PRODUTOS-->
    <li>
        <img src="uploads/<?php echo $categoria; ?>/<?php echo $imagem; ?>" alt="" height="330" width="490"/>
      <p>
        <a href="index.php?infonews=nav/single_pages&amp;infonew=<?php echo $id_do_post; ?>">
        <h1><?php echo $titulo; ?></h1>
         <?php echo strip_tags(trim(str_truncate($texto, 150))); ?>...<strong>Continue Lendo.</strong>
        </a>
      </p>
   </li>
<?php 
}else if($recupera == 'lista'){
?>
<li>
  <a href="index.php?infonews=nav/single_pages&amp;infonew=<?php echo $id_do_post; ?>">
     <span><?php echo $numero; ?></span>
       <img src="uploads/<?php echo $categoria; ?>/<?php echo $imagem; ?>" alt="" width="100" height="58"/>
      <h1><?php echo strip_tags(trim(str_truncate($titulo, 30))); ?>...</h1>
      <p><?php echo strip_tags(trim(str_truncate($texto, 95))); ?>...</p><br/>
      <h2 align="left"><strong>Por: <?php echo $autor; ?></strong></h2>
  </a>
</li>
<?php 
}else if($recupera == 'tecnologia'){
?>
<li>
   <a href="index.php?infonews=nav/single_pages&amp;infonew=<?php echo $id_do_post; ?>">
      <img src="uploads/<?php echo $categoria; ?>/<?php echo $imagem; ?>" alt="" width="200" height="110" />
      		<h1><?php echo $titulo; ?></h1>
            <p><?php echo strip_tags(trim(str_truncate($texto, 250))); ?>...<strong>Continue Lendo.</strong></p>
   </a>
</li>
<?php 
}else if($recupera == 'produtos'){
?>
<li>
    <a href="index.php?infonews=nav/single_pages&amp;infonew=<?php echo $id_do_post; ?>">
       <img src="uploads/<?php echo $categoria; ?>/<?php echo $imagem; ?>" width="75" height="75" alt="" />
       <p><?php echo strip_tags(trim(str_truncate($texto, 85))); ?></p>
      <span>R$ <?php echo $valor_real; ?></span>
    </a>
 </li>
<?php 
}else if($recupera == 'diversos'){
?>
<div id="diversos_page">	
            <h2><?php echo $titulo; ?></h2>
            <p>
            <?php echo strip_tags(trim(str_truncate($texto, 1200))); ?>...
            <a href="index.php?infonews=nav/single_pages&amp;infonew=<?php echo $id_do_post; ?>"><strong>Continue Lendo.</strong></a>
            </p>
            <span>Por - <?php echo $autor; ?></span>
</div><!--diversos PAGE-->
            
<div id="diversos_ilustra">
            	<img src="uploads/<?php echo $categoria; ?>/<?php echo $imagem; ?>" width="330" />
</div><!--diversos ILUSTRAÇÃO-->

<?php
}
?>
<?php
	}
}
?>

</ul>
