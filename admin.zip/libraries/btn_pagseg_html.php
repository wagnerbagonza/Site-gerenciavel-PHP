<form target="pagseguro" method="post" action="https://pagseguro.uol.com.br/checkout/checkout.jhtml" class="form_pag">
  <input type="hidden" name="email_cobranca" value="willton_23@hotmail.com" />
  <input type="hidden" name="tipo" value="CBR" />
  <input type="hidden" name="moeda" value="BRL" />
  <input type="hidden" name="item_id" value="<?php echo $infonew; ?>" />
  <input type="hidden" name="item_descr" value="<?php echo $titulo; ?>" />
  <input type="hidden" name="item_quant" value="1" />
  <input type="hidden" name="item_valor" value="<?php echo $valor_pagseguro; ?>" />
  <input type="hidden" name="frete" value="0" />
  <input type="hidden" name="peso" value="0" />
  <input type="image" name="submit" 
  src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/99x61-comprar-assina.gif"
  alt="Pague com PagSeguro - é rápido, grátis e seguro!" class="btn_pag" />
  <span class="msg_pag">Clique em Comprar com PagSeguro e compre pelo meio de pagamento mais seguro da Internet!</span>
</form>