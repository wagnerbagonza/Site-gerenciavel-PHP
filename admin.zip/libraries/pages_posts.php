<?php 
$infonew = $_GET['infonew'];
//O CÓDIGO ABAIXO RECUPERA OS VALORES DO BANCO PARA MOSTRAR O POST DE ACORDO COM A COTEGORIA
$noticias =  mysql_query("SELECT 
							 thumb, 
							 titulo, 
							 texto, 
							 categoria, 
							 `data`, 
							 autor, 
							 valor_real, 
							 valor_pagseguro,
							 visitas
							 FROM info_posts 
							 WHERE id_post = '$infonew'")
				 or die(mysql_error());
	if(@mysql_num_rows($noticias) <='0'){
		echo "Desculpe. Entamos alimentando o Site!";
		}else{
			
			$numero = '0';
			while($rs_noticias=mysql_fetch_array($noticias)){
				
				$thumb = $rs_noticias[0];
				$titulo = $rs_noticias[1];
				$texto = $rs_noticias[2];
				$categoria = $rs_noticias[3];
				$data = $rs_noticias[4];
				$autor = $rs_noticias[5];
				$valor_real = $rs_noticias[6];
				$valor_pagseguro = $rs_noticias[7];
				$visitas = $rs_noticias[8];
				$numero++;
//CÍDIGO PARA MOSTRAR A QUANTIDADE DE VISITAS POR POST			
$add_visitas = $visitas + 1;
$info_visitas = mysql_query("UPDATE 
							info_posts 
							SET visitas = '$add_visitas', data = 'data' WHERE id_post = '$infonew'")
	or die(mysql_error());
	//GERA O HTML PARA MOSTAR OS POSTS DE UMA UNICA CATEGORIA DA SIDEBAR
	$categ_html = "<h1>$titulo;</h1>
        <p class='info'>Autor: $autor | Categoria: $categoria; | Visitas: $visitas</p>
        <a href='uploads/$categoria/$thumb' rel='shadowbox'>
        <img src='uploads/$categoria/$thumb' alt='' width='350' class='alinright'/>
        </a>
  		<p class='posts'>$texto</p>"
?>

<?php 
//
echo $categ_html; 
?>

<?php 
//ESSA CONDIÇÃO COMPARA SE A CATEGORIA É PRODUTO. SENDO PEODUTOS DA 
//CATEGORIA PRODUTO, ELA RECUPERA O BOTÃO DO PAG SEGURO, LEVANDO O USUÁRIO AO CARRINHO DE COMPRA, CASO CLIQUE NO BOTÃO

if($categoria == 'produtos'){ 
?>

<?php include_once("btn_pagseg_html.php");?>

<?php
}else{
}
?>
<?php
	}
}
?>


