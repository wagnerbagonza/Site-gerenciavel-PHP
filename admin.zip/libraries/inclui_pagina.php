<?php 

//ESSE FAZ A CHAMDA DAS PAGINAS NO BANCO, PARA LISTA O CONTEUDO DE CADA UMA DELAS.
//ESSAS SÃO PÁGINAS COM MENU SUPERIOR ESTÁTICO, OU SEJA, NÃO SÃO DAS CATEGOTIAS.
 $pagina = $_GET['pagina'];
 $pagina_sql = mysql_query("SELECT
						id_page,
						pagina,
						conteudo
						FROM info_page
						WHERE pagina = '$pagina'")
 or die(mysql_error());
 if(@mysql_num_rows($pagina_sql) == '0'){
	echo "Erro ao selecionar a página!";	 
}else{
	while($rs_pagina=mysql_fetch_array($pagina_sql)){
		$id_page = $rs_pagina[0];
		$pagina = $rs_pagina[1];
		$conteudo = $rs_pagina[2];
?>
    
    	<h1><?php echo $pagina; ?></h1>
  			<?php echo $conteudo; ?>
<?php
	}
}
?>